const Emp= require('../models/emp')

exports.formpage=(req,res)=>{
    res.render('form.ejs',{message:''})
}
exports.formdatainsert=(req,res)=>{
    const {fname,lname,depart,salary}=req.body
    const filename=req.file.filename
     const record= new Emp({firstName:fname,lastName:lname,depart:depart,salary:salary,img:filename})
       record.save()
       res.render('form.ejs',{message:'Successfully Data inserted'})
}
exports.dataselection= async (req,res)=>{
    const record=await Emp.find()     
     res.render('selection.ejs',{record})
}
exports.updateform= async (req,res)=>{
    const id=req.params.id
    const record=await Emp.findById(id)    
      res.render('updateform.ejs',{record})
}
exports.dataupdate= async (req,res)=>{
     const {fname,lname,depart,salary}=req.body
     const id=req.params.id     
     if(req.file){
        const filename=req.file.filename
        await Emp.findByIdAndUpdate(id,{firstName:fname,lastName:lname,salary:salary,depart:depart,img:filename})
     }else{
        
        await Emp.findByIdAndUpdate(id,{firstName:fname,lastName:lname,salary:salary,depart:depart})
     }    
     res.redirect('/selection')
   
}
exports.datadelete= async (req,res)=>{
       const id=req.params.id
       await Emp.findByIdAndDelete(id)
      res.redirect('/selection')
}