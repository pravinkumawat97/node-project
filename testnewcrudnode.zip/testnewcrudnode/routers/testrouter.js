const router= require('express').Router()
const empc=require('../controllers/empcontroller')
const upload= require('../helper/multer')

router.get('/',(req,res)=>{
     res.render('home.ejs')
})
router.get('/form',empc.formpage)
router.post('/form',upload.single('img'),empc.formdatainsert)
router.get('/selection',empc.dataselection)
router.get('/update/:id',empc.updateform)
router.post('/update/:id',upload.single('img'),empc.dataupdate)
router.get('/delete/:id',empc.datadelete)

 module.exports=router