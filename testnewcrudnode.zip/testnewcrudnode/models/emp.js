const mongoose= require('mongoose')

const empSchema= mongoose.Schema({
    firstName:String,
    lastName:String,
    depart:String,
    salary:Number,
    img:String,
    date:{type:Date,default:new Date()}
 })

module.exports= mongoose.model('emp',empSchema)